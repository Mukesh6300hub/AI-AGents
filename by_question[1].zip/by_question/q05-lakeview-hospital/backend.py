"""Backend - Q5: Emergency Triage Optimizer | Lakeview Hospital
Run: pip install fastapi uvicorn && uvicorn backend:app --reload   (docs at /docs)
GET /preset -> default inputs   GET /optimize/default -> run on defaults   GET /ai-optimizer -> best setting   POST /optimize -> run on your inputs
"""
import math
from typing import List
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

app = FastAPI(title="Q5 Emergency Triage Optimizer - Lakeview Hospital")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])
Phi = lambda x: 0.5 * (1 + math.erf(x / math.sqrt(2)))

class A(BaseModel):  # review-band thresholds
    N: float; p: float; d: float; cFP: float; cFN: float; r: float; cap: float


def engine_a(q: A):
    pp, best, base = q.p / 100, None, None
    steps = int((q.d + 6) / 0.05)
    for i in range(steps):
        tl = -3 + i * .05
        for j in range(i, steps):
            th = -3 + j * .05
            fn = pp * Phi(tl - q.d); fp = (1 - pp) * (1 - Phi(th))
            rv = pp * (Phi(th - q.d) - Phi(tl - q.d)) + (1 - pp) * (Phi(th) - Phi(tl))
            if q.N * rv > q.cap:
                continue
            cost = q.N * (q.cFN * fn + q.cFP * fp + q.r * rv)
            o = dict(t_low=round(tl, 2), t_high=round(th, 2), cost=cost, wrong_low=q.N * fn,
                     wrong_high=q.N * fp, reviews=q.N * rv)
            if best is None or cost < best["cost"]:
                best = o
            if j == i and (base is None or cost < base["cost"]):
                base = o
    return {"optimal": best, "no_review_baseline": base}


PRESET = {
  "n": 5,
  "name": "Emergency Triage Optimizer",
  "company": "Lakeview Hospital",
  "desc": "Lakeview proposes AI that ranks waiting patients. This tool sets the fast-track, routine and nurse-reassessment bands so overloaded nurses still check the risky cases.",
  "eng": "A",
  "hi": [
    "Fast-track",
    "Routine queue"
  ],
  "v": [
    3000,
    10,
    2,
    200,
    500000,
    300,
    600
  ],
  "tip": "Positive = critically ill patient. Make overrides one tap, track them, and audit missed critical cases weekly to fight automation bias."
}


@app.get("/preset")
def preset():
    return PRESET


@app.post("/optimize")
def optimize(q: A):
    return engine_a(q)


@app.get("/optimize/default")
def optimize_default():
    v = PRESET.get("v")
    a = A(N=v[0], p=v[1], d=v[2], cFP=v[3], cFN=v[4], r=v[5], cap=v[6])
    return engine_a(a)


@app.get("/ai-optimizer")
def ai_optimizer():
    from optimizer import best_settings  # imported lazily to avoid a circular import
    return best_settings()
