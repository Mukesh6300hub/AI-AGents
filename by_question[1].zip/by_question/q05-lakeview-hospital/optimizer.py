"""AI Optimizer - Q5: Emergency Triage Optimizer | Lakeview Hospital
Scans the one constraint that matters and returns the best setting.
Needs backend.py in the same folder. Run: python optimizer.py
"""
import json
from backend import *  # engine, input models and PRESET


def best_settings():
    v = PRESET["v"]
    best = None
    for pct in range(10, 201, 10):  # review capacity from 10% to 200% of the input
        r = engine_a(A(N=v[0], p=v[1], d=v[2], cFP=v[3], cFN=v[4], r=v[5], cap=v[6] * pct / 100))["optimal"]
        if best is None or r["cost"] < best[1]["cost"] - 1e-6:
            best = (pct, r)
    pct, r = best
    return {"setting": "human review capacity (reviews/month)", "best_value": v[6] * pct / 100,
            "percent_of_input": pct, "cut_off_low": r["t_low"], "cut_off_high": r["t_high"],
            "reviews": r["reviews"], "total_cost": r["cost"],
            "message": "Beyond this capacity, extra reviewers cost more than the errors they prevent."}


if __name__ == "__main__":
    print(json.dumps(best_settings(), indent=2, ensure_ascii=False))
