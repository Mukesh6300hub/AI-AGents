# Q8: Call-Centre Monitoring Optimizer | ConnectWorks BPO

ConnectWorks scores 2,000 agents’ calls with AI for appraisals and terminations. This tool allocates limited human audit hours to the groups where unfair AI scores are most likely.

**Legal / ethics note:** An AI score should never alone drive termination. EU-client work brings AI Act workplace rules.

Default inputs (illustrative): `[["EU-client agents", 500, 150, 1], ["New agents", 300, 100, 1], ["Low AI scorers", 350, 120, 1], ["Tenured agents", 60, 200, 1]]` with budget 400 audit hours/mo

## Engine C - diminishing-returns allocation (Q2, Q7, Q8, Q9, Q12, Q15)
value_i(x) = ceiling_i * (1 - e^(-x/scale_i)) * value_per_unit_i      (concave)
x = 0; repeat 3000 times: add budget/3000 to the option with the largest marginal gain
(respecting max share per option). Optimal for concave curves. Baseline = equal split.
AI Optimizer: scan budget 50%..200%; pick max of value - unit_cost * budget.

Assumptions to replace with real data: normal score distributions (A), exponential amounts and perfect human review (B), saturating curves (C), constant elasticity (D).
