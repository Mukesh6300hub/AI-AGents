"""Backend - Q8: Call-Centre Monitoring Optimizer | ConnectWorks BPO
Run: pip install fastapi uvicorn && uvicorn backend:app --reload   (docs at /docs)
GET /preset -> default inputs   GET /optimize/default -> run on defaults   GET /ai-optimizer -> best setting   POST /optimize -> run on your inputs
"""
import math
from typing import List
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

app = FastAPI(title="Q8 Call-Centre Monitoring Optimizer - ConnectWorks BPO")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])
Phi = lambda x: 0.5 * (1 + math.erf(x / math.sqrt(2)))

class Opt(BaseModel):
    name: str; ceil: float; scale: float; value: float


class C(BaseModel):  # diminishing-returns allocation
    budget: float; options: List[Opt]


def engine_c(q: C):
    x = [0.0] * len(q.options); step = q.budget / 4000
    f = lambda o, v: o.ceil * (1 - math.exp(-v / o.scale)) * o.value
    for _ in range(4000):
        gains = [f(o, x[i] + step) - f(o, x[i]) for i, o in enumerate(q.options)]
        x[gains.index(max(gains))] += step
    eq = sum(f(o, q.budget / len(x)) for o in q.options)
    tot = sum(f(o, v) for o, v in zip(q.options, x))
    return {"allocation": {o.name: round(v, 2) for o, v in zip(q.options, x)},
            "total_value": tot, "equal_split_value": eq, "uplift_pct": (tot / eq - 1) * 100}


PRESET = {
  "n": 8,
  "name": "Call-Centre Monitoring Optimizer",
  "company": "ConnectWorks BPO",
  "desc": "ConnectWorks scores 2,000 agents’ calls with AI for appraisals and terminations. This tool allocates limited human audit hours to the groups where unfair AI scores are most likely.",
  "eng": "C",
  "bud": 400,
  "unit": "audit hours/mo",
  "uc": 0.05,
  "opts": [
    [
      "EU-client agents",
      500,
      150,
      1
    ],
    [
      "New agents",
      300,
      100,
      1
    ],
    [
      "Low AI scorers",
      350,
      120,
      1
    ],
    [
      "Tenured agents",
      60,
      200,
      1
    ]
  ],
  "tip": "An AI score should never alone drive termination. EU-client work brings AI Act workplace rules."
}


@app.get("/preset")
def preset():
    return PRESET


@app.post("/optimize")
def optimize(q: C):
    return engine_c(q)


@app.get("/optimize/default")
def optimize_default():
    v = PRESET.get("v")
    a = C(budget=PRESET["bud"], options=[Opt(name=o[0], ceil=o[1], scale=o[2], value=o[3]) for o in PRESET["opts"]])
    return engine_c(a)


@app.get("/ai-optimizer")
def ai_optimizer():
    from optimizer import best_settings  # imported lazily to avoid a circular import
    return best_settings()
