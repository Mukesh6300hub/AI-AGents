"""Backend - Q7: No-Code Automation Governance Optimizer | SwiftHaul Logistics
Run: pip install fastapi uvicorn && uvicorn backend:app --reload   (docs at /docs)
GET /preset -> default inputs   GET /optimize/default -> run on defaults   GET /ai-optimizer -> best setting   POST /optimize -> run on your inputs
"""
import math
from typing import List
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

app = FastAPI(title="Q7 No-Code Automation Governance Optimizer - SwiftHaul Logistics")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])
Phi = lambda x: 0.5 * (1 + math.erf(x / math.sqrt(2)))

class Opt(BaseModel):
    name: str; ceil: float; scale: float; value: float


class C(BaseModel):  # diminishing-returns allocation
    budget: float; options: List[Opt]


def engine_c(q: C):
    x = [0.0] * len(q.options); step = q.budget / 4000
    f = lambda o, v: o.ceil * (1 - math.exp(-v / o.scale)) * o.value
    for _ in range(4000):
        gains = [f(o, x[i] + step) - f(o, x[i]) for i, o in enumerate(q.options)]
        x[gains.index(max(gains))] += step
    eq = sum(f(o, q.budget / len(x)) for o in q.options)
    tot = sum(f(o, v) for o, v in zip(q.options, x))
    return {"allocation": {o.name: round(v, 2) for o, v in zip(q.options, x)},
            "total_value": tot, "equal_split_value": eq, "uplift_pct": (tot / eq - 1) * 100}


PRESET = {
  "n": 7,
  "name": "No-Code Automation Governance Optimizer",
  "company": "SwiftHaul Logistics",
  "desc": "Dispatch staff build their own AI automations and dozens already exist ungoverned. This tool spreads limited governance effort across automation risk classes.",
  "eng": "C",
  "bud": 60,
  "unit": "person-days",
  "uc": 0.1,
  "opts": [
    [
      "Customer messaging",
      300,
      20,
      1
    ],
    [
      "Route reassignment",
      250,
      25,
      1
    ],
    [
      "Internal alerts",
      40,
      15,
      1
    ],
    [
      "Data exports",
      200,
      15,
      1
    ]
  ],
  "tip": "Inventory every existing automation first and add an approval gate before anything new goes live."
}


@app.get("/preset")
def preset():
    return PRESET


@app.post("/optimize")
def optimize(q: C):
    return engine_c(q)


@app.get("/optimize/default")
def optimize_default():
    v = PRESET.get("v")
    a = C(budget=PRESET["bud"], options=[Opt(name=o[0], ceil=o[1], scale=o[2], value=o[3]) for o in PRESET["opts"]])
    return engine_c(a)


@app.get("/ai-optimizer")
def ai_optimizer():
    from optimizer import best_settings  # imported lazily to avoid a circular import
    return best_settings()
