# Q7: No-Code Automation Governance Optimizer | SwiftHaul Logistics

Dispatch staff build their own AI automations and dozens already exist ungoverned. This tool spreads limited governance effort across automation risk classes.

**Legal / ethics note:** Inventory every existing automation first and add an approval gate before anything new goes live.

Default inputs (illustrative): `[["Customer messaging", 300, 20, 1], ["Route reassignment", 250, 25, 1], ["Internal alerts", 40, 15, 1], ["Data exports", 200, 15, 1]]` with budget 60 person-days

## Engine C - diminishing-returns allocation (Q2, Q7, Q8, Q9, Q12, Q15)
value_i(x) = ceiling_i * (1 - e^(-x/scale_i)) * value_per_unit_i      (concave)
x = 0; repeat 3000 times: add budget/3000 to the option with the largest marginal gain
(respecting max share per option). Optimal for concave curves. Baseline = equal split.
AI Optimizer: scan budget 50%..200%; pick max of value - unit_cost * budget.

Assumptions to replace with real data: normal score distributions (A), exponential amounts and perfect human review (B), saturating curves (C), constant elasticity (D).
