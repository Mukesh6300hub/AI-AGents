# Q11: Fraud & Account Freeze Optimizer | PayNest

PayNest freezes accounts the AI flags, and small merchants lose daily income during review. This tool sets allow, freeze and fast-review bands.

**Legal / ethics note:** Positive = legitimate transaction. Use a review band instead of instant freezes and give small merchants a same-day review SLA.

Default inputs (illustrative): `[500000, 98, 2.5, 8000, 1500, 50, 3000]`

## Engine A - review-band thresholds (Q1 Talent360, Q4 QuickRupee, Q5 Lakeview, Q11 PayNest, Q13 Metro City)
Scores: negatives ~ N(0,1), positives ~ N(d',1); prevalence p; volume N.
for every pair (t_low <= t_high) on a 0.05 grid:
    FN   = p * Phi(t_low - d')                       # positives auto-actioned the wrong way (low side)
    FP   = (1-p) * (1 - Phi(t_high))                 # negatives auto-actioned the wrong way (high side)
    REV  = p*(Phi(t_high-d') - Phi(t_low-d')) + (1-p)*(Phi(t_high) - Phi(t_low))
    skip if N*REV > review_capacity
    cost = N * (cFN*FN + cFP*FP + review_cost*REV)
choose the pair with minimum cost. Baseline = best single threshold (t_low = t_high, no review).
AI Optimizer: repeat for capacity = 10%..200% of input, pick the capacity with the lowest cost.

Assumptions to replace with real data: normal score distributions (A), exponential amounts and perfect human review (B), saturating curves (C), constant elasticity (D).
