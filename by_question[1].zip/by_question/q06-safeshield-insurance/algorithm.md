# Q6: Insurance Claims Optimizer | SafeShield Insurance

SafeShield wants an agentic AI to read claims and pay small ones automatically. This tool finds the auto-pay cap that balances processing cost against missed fraud and wrongly paid claims.

**Legal / ethics note:** Always send denials and fraud flags to a human so genuine claims are not wrongly rejected.

Default inputs (illustrative): `[8000, 18000, 5, 60, 450, 15, 1500000]`

## Engine B - authority cap (Q3 Kaveri Bank, Q6 SafeShield, Q14 Orion Retail)
Item amounts ~ Exponential(mean m). AI decides alone if amount <= L, else a human does.
share(L) = 1 - e^(-L/m)
loss(L)  = N * err * loss_frac * (m - (L+m) e^(-L/m))
cost(L)  = N * (share*ai_cost + (1-share)*human_cost) + loss(L)
choose L minimising cost(L) subject to loss(L) <= loss_tolerance. Baselines: all-human, all-AI.
AI Optimizer: scan loss tolerance 10%..300%; report the cheapest cap.

Assumptions to replace with real data: normal score distributions (A), exponential amounts and perfect human review (B), saturating curves (C), constant elasticity (D).
