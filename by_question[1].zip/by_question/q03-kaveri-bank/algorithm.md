# Q3: Card Dispute & Refund Optimizer | Kaveri Bank

Kaveri Bank wants an AI agent to resolve card disputes and approve refunds up to ₹5,000 alone. This tool finds the refund cap that balances handling cost against wrongly approved refunds.

**Legal / ethics note:** Limit the agent to the data each dispute needs; log every approval and route repeat complainants to a person.

Default inputs (illustrative): `[30000, 2500, 4, 100, 180, 6, 300000]`

## Engine B - authority cap (Q3 Kaveri Bank, Q6 SafeShield, Q14 Orion Retail)
Item amounts ~ Exponential(mean m). AI decides alone if amount <= L, else a human does.
share(L) = 1 - e^(-L/m)
loss(L)  = N * err * loss_frac * (m - (L+m) e^(-L/m))
cost(L)  = N * (share*ai_cost + (1-share)*human_cost) + loss(L)
choose L minimising cost(L) subject to loss(L) <= loss_tolerance. Baselines: all-human, all-AI.
AI Optimizer: scan loss tolerance 10%..300%; report the cheapest cap.

Assumptions to replace with real data: normal score distributions (A), exponential amounts and perfect human review (B), saturating curves (C), constant elasticity (D).
