"""AI Optimizer - Q3: Card Dispute & Refund Optimizer | Kaveri Bank
Scans the one constraint that matters and returns the best setting.
Needs backend.py in the same folder. Run: python optimizer.py
"""
import json
from backend import *  # engine, input models and PRESET


def best_settings():
    v = PRESET["v"]
    best = None
    for pct in range(10, 301, 10):  # loss tolerance from 10% to 300% of the input
        r = engine_b(B(N=v[0], m=v[1], e=v[2], f=v[3], h=v[4], a=v[5], B=v[6] * pct / 100))["optimal"]
        if r and (best is None or r["cost"] < best[1]["cost"] - 1e-6):
            best = (pct, r)
    if best is None:
        return {"message": "No feasible cap at these error rates."}
    pct, r = best
    return {"setting": "loss tolerance per month", "best_value": v[6] * pct / 100, "percent_of_input": pct,
            "ai_authority_cap": r["cap"], "ai_share": r["auto_share"], "expected_loss": r["loss"],
            "total_cost": r["cost"], "message": "Lowest-cost AI authority cap for this error profile."}


if __name__ == "__main__":
    print(json.dumps(best_settings(), indent=2, ensure_ascii=False))
