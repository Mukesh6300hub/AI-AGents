# Q14: Procurement Agent Optimizer | Orion Retail

Orion proposes an AI agent that negotiates and places purchase orders up to ₹10 lakh without approval. This tool finds the approval-free spending cap.

**Legal / ethics note:** Whitelist suppliers, guard against prompt injection, and require human sign-off on non-standard terms.

Default inputs (illustrative): `[600, 400000, 3, 15, 2500, 100, 500000]`

## Engine B - authority cap (Q3 Kaveri Bank, Q6 SafeShield, Q14 Orion Retail)
Item amounts ~ Exponential(mean m). AI decides alone if amount <= L, else a human does.
share(L) = 1 - e^(-L/m)
loss(L)  = N * err * loss_frac * (m - (L+m) e^(-L/m))
cost(L)  = N * (share*ai_cost + (1-share)*human_cost) + loss(L)
choose L minimising cost(L) subject to loss(L) <= loss_tolerance. Baselines: all-human, all-AI.
AI Optimizer: scan loss tolerance 10%..300%; report the cheapest cap.

Assumptions to replace with real data: normal score distributions (A), exponential amounts and perfect human review (B), saturating curves (C), constant elasticity (D).
