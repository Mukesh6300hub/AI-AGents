"""Backend - Q14: Procurement Agent Optimizer | Orion Retail
Run: pip install fastapi uvicorn && uvicorn backend:app --reload   (docs at /docs)
GET /preset -> default inputs   GET /optimize/default -> run on defaults   GET /ai-optimizer -> best setting   POST /optimize -> run on your inputs
"""
import math
from typing import List
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

app = FastAPI(title="Q14 Procurement Agent Optimizer - Orion Retail")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])
Phi = lambda x: 0.5 * (1 + math.erf(x / math.sqrt(2)))

class B(BaseModel):  # authority cap
    N: float; m: float; e: float; f: float; h: float; a: float; B: float


def engine_b(q: B):
    E, F, best = q.e / 100, q.f / 100, None
    for i in range(2001):
        L = i * q.m * 10 / 2000; k = math.exp(-L / q.m); share = 1 - k
        loss = q.N * E * F * (q.m - (L + q.m) * k)
        cost = q.N * (share * q.a + k * q.h) + loss
        if loss <= q.B and (best is None or cost < best["cost"]):
            best = dict(cap=L, auto_share=share, loss=loss, cost=cost)
    return {"optimal": best, "all_human_cost": q.N * q.h,
            "all_auto_cost": q.N * q.a + q.N * E * F * q.m}


PRESET = {
  "n": 14,
  "name": "Procurement Agent Optimizer",
  "company": "Orion Retail",
  "desc": "Orion proposes an AI agent that negotiates and places purchase orders up to ₹10 lakh without approval. This tool finds the approval-free spending cap.",
  "eng": "B",
  "v": [
    600,
    400000,
    3,
    15,
    2500,
    100,
    500000
  ],
  "tip": "Whitelist suppliers, guard against prompt injection, and require human sign-off on non-standard terms."
}


@app.get("/preset")
def preset():
    return PRESET


@app.post("/optimize")
def optimize(q: B):
    return engine_b(q)


@app.get("/optimize/default")
def optimize_default():
    v = PRESET.get("v")
    a = B(N=v[0], m=v[1], e=v[2], f=v[3], h=v[4], a=v[5], B=v[6])
    return engine_b(a)


@app.get("/ai-optimizer")
def ai_optimizer():
    from optimizer import best_settings  # imported lazily to avoid a circular import
    return best_settings()
