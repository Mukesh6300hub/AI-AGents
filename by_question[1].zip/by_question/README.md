# AI Decision Optimizers: 15 Business Problems

One small optimizer per company problem. Each problem has its own folder with an **algorithm write-up**, a **standalone frontend** and a **FastAPI backend**.

> **Important:** every number in this repo is simulated and illustrative. None of it is real company data, and the company names are used only as examples. Replace the inputs with your own data before using any result for a decision. The legal and ethics notes flag issues to check; they are not legal advice.

## The 15 problems

| # | Folder | Company | Problem | Engine |
|---|---|---|---|---|
| 1 | `q01-talent360` | Talent360 | HR screening | A |
| 2 | `q02-veda-components` | Veda Components | Contract review | C |
| 3 | `q03-kaveri-bank` | Kaveri Bank | Card disputes and refunds | B |
| 4 | `q04-quickrupee` | QuickRupee | Instant lending | A |
| 5 | `q05-lakeview-hospital` | Lakeview Hospital | Emergency triage | A |
| 6 | `q06-safeshield-insurance` | SafeShield Insurance | Insurance claims | B |
| 7 | `q07-swifthaul-logistics` | SwiftHaul Logistics | No-code automation governance | C |
| 8 | `q08-connectworks-bpo` | ConnectWorks BPO | Call-centre monitoring | C |
| 9 | `q09-horizon-b-school` | Horizon B-School | Admissions and scholarships | C |
| 10 | `q10-bazaarly` | Bazaarly | Dynamic pricing | D |
| 11 | `q11-paynest` | PayNest | Fraud and account freezing | A |
| 12 | `q12-fresco-foods` | Fresco Foods | Generative marketing | C |
| 13 | `q13-metro-city-corporation` | Metro City Corporation | Public services | A |
| 14 | `q14-orion-retail` | Orion Retail | Procurement agent | B |
| 15 | `q15-learnloop` | LearnLoop | AI tutor for schools | C |

## The four engines

- **A. Review-band thresholds.** Finds the low and high score cut-offs that auto-reject, auto-approve or send to a human, at the lowest total cost within reviewer capacity.
- **B. Authority cap.** Finds the highest amount an AI may decide alone, balancing handling cost against error loss.
- **C. Diminishing-returns allocation.** Splits a limited budget (money, hours, days) across options by repeatedly funding the best marginal return.
- **D. Price within a fairness band.** Finds the profit-maximising price when no customer may pay more than ±g% from a reference price.

Each folder's `algorithm.md` has the step-by-step method for its engine.

## Folder layout

```
qNN-company/
  algorithm.md    problem, legal/ethics note, default inputs, algorithm
  frontend.html   standalone page, open directly in a browser
  backend.py      self-contained FastAPI service
  optimizer.py    AI Optimizer: scans the key constraint and returns the best setting
```

## Run the frontend

Open `frontend.html` in any browser. No server or install is needed. Edit the inputs, move the sliders, or press **Apply best settings** to let the optimizer choose.

## Run a backend

```bash
pip install -r requirements.txt
cd q03-kaveri-bank
uvicorn backend:app --reload
```

Then open `http://127.0.0.1:8000/docs`.

| Endpoint | What it does |
|---|---|
| `GET /preset` | Returns the default inputs |
| `GET /optimize/default` | Runs the optimizer on the defaults |
| `POST /optimize` | Runs the engine on your own inputs (see `/docs` for the schema) |
| `GET /ai-optimizer` | Runs the AI Optimizer and returns the best setting |

You can also run `python optimizer.py` inside a folder to print the best setting.

The frontend runs the same algorithm in the browser and does not call the backend. The backend is a separate copy for use in your own application.

## Known limitations

- The engines rest on simplifying assumptions: normal score distributions and perfect human review (A and B), exponential amounts (B), saturating response curves (C), and constant price elasticity (D). Real data will differ.
- The backend's engine C has no "max share per option" limit, but the frontend does, so results can differ when that slider is below 100%.
- The backends have been syntax-checked but not load-tested.
