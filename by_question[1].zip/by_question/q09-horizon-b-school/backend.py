"""Backend - Q9: Admissions & Scholarship Optimizer | Horizon B-School
Run: pip install fastapi uvicorn && uvicorn backend:app --reload   (docs at /docs)
GET /preset -> default inputs   GET /optimize/default -> run on defaults   GET /ai-optimizer -> best setting   POST /optimize -> run on your inputs
"""
import math
from typing import List
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

app = FastAPI(title="Q9 Admissions & Scholarship Optimizer - Horizon B-School")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])
Phi = lambda x: 0.5 * (1 + math.erf(x / math.sqrt(2)))

class Opt(BaseModel):
    name: str; ceil: float; scale: float; value: float


class C(BaseModel):  # diminishing-returns allocation
    budget: float; options: List[Opt]


def engine_c(q: C):
    x = [0.0] * len(q.options); step = q.budget / 4000
    f = lambda o, v: o.ceil * (1 - math.exp(-v / o.scale)) * o.value
    for _ in range(4000):
        gains = [f(o, x[i] + step) - f(o, x[i]) for i, o in enumerate(q.options)]
        x[gains.index(max(gains))] += step
    eq = sum(f(o, q.budget / len(x)) for o in q.options)
    tot = sum(f(o, v) for o, v in zip(q.options, x))
    return {"allocation": {o.name: round(v, 2) for o, v in zip(q.options, x)},
            "total_value": tot, "equal_split_value": eq, "uplift_pct": (tot / eq - 1) * 100}


PRESET = {
  "n": 9,
  "name": "Admissions & Scholarship Optimizer",
  "company": "Horizon B-School",
  "desc": "Horizon wants AI to shortlist applicants and suggest scholarship amounts. This tool splits a scholarship pool across applicant tiers for the most impact.",
  "eng": "C",
  "bud": 500,
  "unit": "₹ lakh",
  "uc": 1,
  "opts": [
    [
      "High need, high merit",
      40,
      120,
      1
    ],
    [
      "High need, medium merit",
      60,
      150,
      1
    ],
    [
      "Low need, high merit",
      25,
      80,
      1
    ],
    [
      "Others",
      10,
      100,
      1
    ]
  ],
  "tip": "Essay style varies by background: let AI shortlist but have a committee set amounts and review rejections."
}


@app.get("/preset")
def preset():
    return PRESET


@app.post("/optimize")
def optimize(q: C):
    return engine_c(q)


@app.get("/optimize/default")
def optimize_default():
    v = PRESET.get("v")
    a = C(budget=PRESET["bud"], options=[Opt(name=o[0], ceil=o[1], scale=o[2], value=o[3]) for o in PRESET["opts"]])
    return engine_c(a)


@app.get("/ai-optimizer")
def ai_optimizer():
    from optimizer import best_settings  # imported lazily to avoid a circular import
    return best_settings()
