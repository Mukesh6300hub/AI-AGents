# Q9: Admissions & Scholarship Optimizer | Horizon B-School

Horizon wants AI to shortlist applicants and suggest scholarship amounts. This tool splits a scholarship pool across applicant tiers for the most impact.

**Legal / ethics note:** Essay style varies by background: let AI shortlist but have a committee set amounts and review rejections.

Default inputs (illustrative): `[["High need, high merit", 40, 120, 1], ["High need, medium merit", 60, 150, 1], ["Low need, high merit", 25, 80, 1], ["Others", 10, 100, 1]]` with budget 500 ₹ lakh

## Engine C - diminishing-returns allocation (Q2, Q7, Q8, Q9, Q12, Q15)
value_i(x) = ceiling_i * (1 - e^(-x/scale_i)) * value_per_unit_i      (concave)
x = 0; repeat 3000 times: add budget/3000 to the option with the largest marginal gain
(respecting max share per option). Optimal for concave curves. Baseline = equal split.
AI Optimizer: scan budget 50%..200%; pick max of value - unit_cost * budget.

Assumptions to replace with real data: normal score distributions (A), exponential amounts and perfect human review (B), saturating curves (C), constant elasticity (D).
