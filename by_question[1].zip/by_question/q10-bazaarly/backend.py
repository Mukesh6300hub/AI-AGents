"""Backend - Q10: Dynamic Pricing Optimizer | Bazaarly
Run: pip install fastapi uvicorn && uvicorn backend:app --reload   (docs at /docs)
GET /preset -> default inputs   GET /optimize/default -> run on defaults   GET /ai-optimizer -> best setting   POST /optimize -> run on your inputs
"""
import math
from typing import List
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

app = FastAPI(title="Q10 Dynamic Pricing Optimizer - Bazaarly")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])
Phi = lambda x: 0.5 * (1 + math.erf(x / math.sqrt(2)))

class D(BaseModel):  # price within fairness band
    c: float; p0: float; D0: float; e: float; g: float


def engine_d(q: D):
    prof = lambda p: (p - q.c) * q.D0 * (p / q.p0) ** (-q.e)
    lo, hi = q.p0 * (1 - q.g / 100), q.p0 * (1 + q.g / 100)
    ps = [lo + (hi - lo) * i / 1000 for i in range(1001)]
    pb = max(ps, key=prof)
    free = q.c * q.e / (q.e - 1) if q.e > 1 else None
    return {"price": pb, "profit": prof(pb), "demand": q.D0 * (pb / q.p0) ** (-q.e),
            "unconstrained_price": free, "unconstrained_profit": prof(free) if free else None}


PRESET = {
  "n": 10,
  "name": "Dynamic Pricing Optimizer",
  "company": "Bazaarly",
  "desc": "Bazaarly’s AI sets per-customer prices in real time. This tool finds the best price inside a fairness band so two customers never see wildly different prices for the same item.",
  "eng": "D",
  "v": [
    400,
    700,
    10000,
    2.2,
    10
  ],
  "tip": "Avoid location and device as price drivers where they proxy for income; audit price gaps by group."
}


@app.get("/preset")
def preset():
    return PRESET


@app.post("/optimize")
def optimize(q: D):
    return engine_d(q)


@app.get("/optimize/default")
def optimize_default():
    v = PRESET.get("v")
    a = D(c=v[0], p0=v[1], D0=v[2], e=v[3], g=v[4])
    return engine_d(a)


@app.get("/ai-optimizer")
def ai_optimizer():
    from optimizer import best_settings  # imported lazily to avoid a circular import
    return best_settings()
