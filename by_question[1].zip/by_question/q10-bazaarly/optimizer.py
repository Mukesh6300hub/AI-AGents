"""AI Optimizer - Q10: Dynamic Pricing Optimizer | Bazaarly
Scans the one constraint that matters and returns the best setting.
Needs backend.py in the same folder. Run: python optimizer.py
"""
import json
from backend import *  # engine, input models and PRESET


def best_settings():
    v = PRESET["v"]
    def run(g):
        return engine_d(D(c=v[0], p0=v[1], D0=v[2], e=v[3], g=g))
    top = run(40)["profit"]
    for g in range(0, 41):  # fairness band from 0% to 40%
        r = run(g)
        if r["profit"] >= 0.97 * top:
            return {"setting": "fairness band (+/- %)", "best_value": g, "price": r["price"],
                    "profit": r["profit"], "profit_vs_widest_band": r["profit"] / top,
                    "message": "Smallest band that keeps 97% of the best possible profit."}


if __name__ == "__main__":
    print(json.dumps(best_settings(), indent=2, ensure_ascii=False))
