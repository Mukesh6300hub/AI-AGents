# Q10: Dynamic Pricing Optimizer | Bazaarly

Bazaarly’s AI sets per-customer prices in real time. This tool finds the best price inside a fairness band so two customers never see wildly different prices for the same item.

**Legal / ethics note:** Avoid location and device as price drivers where they proxy for income; audit price gaps by group.

Default inputs (illustrative): `[400, 700, 10000, 2.2, 10]`

## Engine D - price inside a fairness band (Q10 Bazaarly)
demand(p) = D0 * (p/p_ref)^(-elasticity);  profit(p) = (p - cost) * demand(p)
search p in [p_ref(1-g), p_ref(1+g)] for max profit. Unconstrained optimum = cost*e/(e-1).
AI Optimizer: smallest band g that keeps >= 97% of the best possible profit.

Assumptions to replace with real data: normal score distributions (A), exponential amounts and perfect human review (B), saturating curves (C), constant elasticity (D).
