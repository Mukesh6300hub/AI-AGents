# Q2: Contract Review Optimizer | Veda Components

Three in-house lawyers handle 1,200 supplier contracts a year. This tool splits scarce lawyer hours across contract tiers where an AI assistant leaves the most risk uncovered.

**Legal / ethics note:** Use a private deployment (terms are confidential) and require clause citations so invented clauses are caught.

Default inputs (illustrative): `[["High-value suppliers", 400, 300, 1], ["Medium suppliers", 250, 400, 1], ["Low-value suppliers", 80, 500, 1], ["Standard / NDAs", 20, 100, 1]]` with budget 1800 lawyer hours/yr

## Engine C - diminishing-returns allocation (Q2, Q7, Q8, Q9, Q12, Q15)
value_i(x) = ceiling_i * (1 - e^(-x/scale_i)) * value_per_unit_i      (concave)
x = 0; repeat 3000 times: add budget/3000 to the option with the largest marginal gain
(respecting max share per option). Optimal for concave curves. Baseline = equal split.
AI Optimizer: scan budget 50%..200%; pick max of value - unit_cost * budget.

Assumptions to replace with real data: normal score distributions (A), exponential amounts and perfect human review (B), saturating curves (C), constant elasticity (D).
