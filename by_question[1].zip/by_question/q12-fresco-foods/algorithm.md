# Q12: Generative Marketing Optimizer | Fresco Foods

Fresco plans AI ads and WhatsApp messages in regional languages with an AI-generated ambassador voice. This tool splits budget across channels.

**Legal / ethics note:** WhatsApp needs recorded consent; licence the AI voice; check every claim; label AI content.

Default inputs (illustrative): `[["Search & app ads", 900, 12, 1.4], ["Social media", 700, 10, 1.25], ["Creators", 300, 5, 1.3], ["WhatsApp / CRM", 500, 3, 1.6], ["Discounts", 1200, 20, 0.7], ["OOH / TV", 800, 18, 1.1]]` with budget 50 ₹ cr

## Engine C - diminishing-returns allocation (Q2, Q7, Q8, Q9, Q12, Q15)
value_i(x) = ceiling_i * (1 - e^(-x/scale_i)) * value_per_unit_i      (concave)
x = 0; repeat 3000 times: add budget/3000 to the option with the largest marginal gain
(respecting max share per option). Optimal for concave curves. Baseline = equal split.
AI Optimizer: scan budget 50%..200%; pick max of value - unit_cost * budget.

Assumptions to replace with real data: normal score distributions (A), exponential amounts and perfect human review (B), saturating curves (C), constant elasticity (D).
