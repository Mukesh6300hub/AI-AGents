"""Backend - Q12: Generative Marketing Optimizer | Fresco Foods
Run: pip install fastapi uvicorn && uvicorn backend:app --reload   (docs at /docs)
GET /preset -> default inputs   GET /optimize/default -> run on defaults   GET /ai-optimizer -> best setting   POST /optimize -> run on your inputs
"""
import math
from typing import List
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

app = FastAPI(title="Q12 Generative Marketing Optimizer - Fresco Foods")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])
Phi = lambda x: 0.5 * (1 + math.erf(x / math.sqrt(2)))

class Opt(BaseModel):
    name: str; ceil: float; scale: float; value: float


class C(BaseModel):  # diminishing-returns allocation
    budget: float; options: List[Opt]


def engine_c(q: C):
    x = [0.0] * len(q.options); step = q.budget / 4000
    f = lambda o, v: o.ceil * (1 - math.exp(-v / o.scale)) * o.value
    for _ in range(4000):
        gains = [f(o, x[i] + step) - f(o, x[i]) for i, o in enumerate(q.options)]
        x[gains.index(max(gains))] += step
    eq = sum(f(o, q.budget / len(x)) for o in q.options)
    tot = sum(f(o, v) for o, v in zip(q.options, x))
    return {"allocation": {o.name: round(v, 2) for o, v in zip(q.options, x)},
            "total_value": tot, "equal_split_value": eq, "uplift_pct": (tot / eq - 1) * 100}


PRESET = {
  "n": 12,
  "name": "Generative Marketing Optimizer",
  "company": "Fresco Foods",
  "desc": "Fresco plans AI ads and WhatsApp messages in regional languages with an AI-generated ambassador voice. This tool splits budget across channels.",
  "eng": "C",
  "bud": 50,
  "unit": "₹ cr",
  "uc": 100,
  "opts": [
    [
      "Search & app ads",
      900,
      12,
      1.4
    ],
    [
      "Social media",
      700,
      10,
      1.25
    ],
    [
      "Creators",
      300,
      5,
      1.3
    ],
    [
      "WhatsApp / CRM",
      500,
      3,
      1.6
    ],
    [
      "Discounts",
      1200,
      20,
      0.7
    ],
    [
      "OOH / TV",
      800,
      18,
      1.1
    ]
  ],
  "tip": "WhatsApp needs recorded consent; licence the AI voice; check every claim; label AI content."
}


@app.get("/preset")
def preset():
    return PRESET


@app.post("/optimize")
def optimize(q: C):
    return engine_c(q)


@app.get("/optimize/default")
def optimize_default():
    v = PRESET.get("v")
    a = C(budget=PRESET["bud"], options=[Opt(name=o[0], ceil=o[1], scale=o[2], value=o[3]) for o in PRESET["opts"]])
    return engine_c(a)


@app.get("/ai-optimizer")
def ai_optimizer():
    from optimizer import best_settings  # imported lazily to avoid a circular import
    return best_settings()
