"""Backend - Q1: HR Screening Optimizer | Talent360
Run: pip install fastapi uvicorn && uvicorn backend:app --reload   (docs at /docs)
GET /preset -> default inputs   GET /optimize/default -> run on defaults   GET /ai-optimizer -> best setting   POST /optimize -> run on your inputs
"""
import math
from typing import List
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

app = FastAPI(title="Q1 HR Screening Optimizer - Talent360")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])
Phi = lambda x: 0.5 * (1 + math.erf(x / math.sqrt(2)))

class A(BaseModel):  # review-band thresholds
    N: float; p: float; d: float; cFP: float; cFN: float; r: float; cap: float


def engine_a(q: A):
    pp, best, base = q.p / 100, None, None
    steps = int((q.d + 6) / 0.05)
    for i in range(steps):
        tl = -3 + i * .05
        for j in range(i, steps):
            th = -3 + j * .05
            fn = pp * Phi(tl - q.d); fp = (1 - pp) * (1 - Phi(th))
            rv = pp * (Phi(th - q.d) - Phi(tl - q.d)) + (1 - pp) * (Phi(th) - Phi(tl))
            if q.N * rv > q.cap:
                continue
            cost = q.N * (q.cFN * fn + q.cFP * fp + q.r * rv)
            o = dict(t_low=round(tl, 2), t_high=round(th, 2), cost=cost, wrong_low=q.N * fn,
                     wrong_high=q.N * fp, reviews=q.N * rv)
            if best is None or cost < best["cost"]:
                best = o
            if j == i and (base is None or cost < base["cost"]):
                base = o
    return {"optimal": best, "no_review_baseline": base}


PRESET = {
  "n": 1,
  "name": "HR Screening Optimizer",
  "company": "Talent360",
  "desc": "Talent360 gets ~40,000 applications a month and wants AI to auto-reject the bottom 60%. This tool finds how many to auto-reject, shortlist or send to a recruiter, given biased past data and EU applicants.",
  "eng": "A",
  "hi": [
    "Shortlist",
    "Auto-reject"
  ],
  "v": [
    40000,
    30,
    1.2,
    500,
    3000,
    150,
    8000
  ],
  "tip": "EU applicants fall under GDPR Art. 22 and the EU AI Act (employment = high-risk): keep a human on rejections and audit outcomes by college and group."
}


@app.get("/preset")
def preset():
    return PRESET


@app.post("/optimize")
def optimize(q: A):
    return engine_a(q)


@app.get("/optimize/default")
def optimize_default():
    v = PRESET.get("v")
    a = A(N=v[0], p=v[1], d=v[2], cFP=v[3], cFN=v[4], r=v[5], cap=v[6])
    return engine_a(a)


@app.get("/ai-optimizer")
def ai_optimizer():
    from optimizer import best_settings  # imported lazily to avoid a circular import
    return best_settings()
