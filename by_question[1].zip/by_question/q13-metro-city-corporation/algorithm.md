# Q13: Public Services Optimizer | Metro City Corporation

Metro City wants AI to prioritise property-tax notices and flag welfare cases. This tool sets clear, flag and officer-review bands for these decisions.

**Legal / ethics note:** Read the DPDP exemptions for government narrowly; an officer decides, and citizens need a simple appeal route.

Default inputs (illustrative): `[100000, 90, 1.3, 2000, 800, 120, 10000]`

## Engine A - review-band thresholds (Q1 Talent360, Q4 QuickRupee, Q5 Lakeview, Q11 PayNest, Q13 Metro City)
Scores: negatives ~ N(0,1), positives ~ N(d',1); prevalence p; volume N.
for every pair (t_low <= t_high) on a 0.05 grid:
    FN   = p * Phi(t_low - d')                       # positives auto-actioned the wrong way (low side)
    FP   = (1-p) * (1 - Phi(t_high))                 # negatives auto-actioned the wrong way (high side)
    REV  = p*(Phi(t_high-d') - Phi(t_low-d')) + (1-p)*(Phi(t_high) - Phi(t_low))
    skip if N*REV > review_capacity
    cost = N * (cFN*FN + cFP*FP + review_cost*REV)
choose the pair with minimum cost. Baseline = best single threshold (t_low = t_high, no review).
AI Optimizer: repeat for capacity = 10%..200% of input, pick the capacity with the lowest cost.

Assumptions to replace with real data: normal score distributions (A), exponential amounts and perfect human review (B), saturating curves (C), constant elasticity (D).
