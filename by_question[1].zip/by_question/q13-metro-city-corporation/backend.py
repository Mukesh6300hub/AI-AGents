"""Backend - Q13: Public Services Optimizer | Metro City Corporation
Run: pip install fastapi uvicorn && uvicorn backend:app --reload   (docs at /docs)
GET /preset -> default inputs   GET /optimize/default -> run on defaults   GET /ai-optimizer -> best setting   POST /optimize -> run on your inputs
"""
import math
from typing import List
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

app = FastAPI(title="Q13 Public Services Optimizer - Metro City Corporation")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])
Phi = lambda x: 0.5 * (1 + math.erf(x / math.sqrt(2)))

class A(BaseModel):  # review-band thresholds
    N: float; p: float; d: float; cFP: float; cFN: float; r: float; cap: float


def engine_a(q: A):
    pp, best, base = q.p / 100, None, None
    steps = int((q.d + 6) / 0.05)
    for i in range(steps):
        tl = -3 + i * .05
        for j in range(i, steps):
            th = -3 + j * .05
            fn = pp * Phi(tl - q.d); fp = (1 - pp) * (1 - Phi(th))
            rv = pp * (Phi(th - q.d) - Phi(tl - q.d)) + (1 - pp) * (Phi(th) - Phi(tl))
            if q.N * rv > q.cap:
                continue
            cost = q.N * (q.cFN * fn + q.cFP * fp + q.r * rv)
            o = dict(t_low=round(tl, 2), t_high=round(th, 2), cost=cost, wrong_low=q.N * fn,
                     wrong_high=q.N * fp, reviews=q.N * rv)
            if best is None or cost < best["cost"]:
                best = o
            if j == i and (base is None or cost < base["cost"]):
                base = o
    return {"optimal": best, "no_review_baseline": base}


PRESET = {
  "n": 13,
  "name": "Public Services Optimizer",
  "company": "Metro City Corporation",
  "desc": "Metro City wants AI to prioritise property-tax notices and flag welfare cases. This tool sets clear, flag and officer-review bands for these decisions.",
  "eng": "A",
  "hi": [
    "Clear",
    "Flag"
  ],
  "v": [
    100000,
    90,
    1.3,
    2000,
    800,
    120,
    10000
  ],
  "tip": "Read the DPDP exemptions for government narrowly; an officer decides, and citizens need a simple appeal route."
}


@app.get("/preset")
def preset():
    return PRESET


@app.post("/optimize")
def optimize(q: A):
    return engine_a(q)


@app.get("/optimize/default")
def optimize_default():
    v = PRESET.get("v")
    a = A(N=v[0], p=v[1], d=v[2], cFP=v[3], cFN=v[4], r=v[5], cap=v[6])
    return engine_a(a)


@app.get("/ai-optimizer")
def ai_optimizer():
    from optimizer import best_settings  # imported lazily to avoid a circular import
    return best_settings()
